# Traditional Chinese Stopwords and Punctuations

This library is created specifically for Traditional Chinese stopwords and punctuations removal.

It also includes NLTK's English stopwords and numbers if you are processing a hybrid of Chinese and English text data.

# Get Started

pip install TCSP

from TCSP import read_stopwords_list

Calling the 'read_stopwords_list()' function will return the stopwords list 
